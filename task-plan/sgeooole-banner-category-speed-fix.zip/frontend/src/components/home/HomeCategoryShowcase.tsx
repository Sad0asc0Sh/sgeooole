"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import useSWR from "swr";
import { ChevronLeft, ChevronRight, Shapes } from "lucide-react";
import { useResilientImage } from "@/components/ui/ResilientImage";
import { categoryService, type Category } from "@/services/categoryService";
import styles from "./HomeCategoryShowcase.module.css";

type HomeCategoryShowcaseProps = {
  /** Server-rendered homepage categories; used as SWR fallback data. */
  categories: Category[] | null;
};

type CategoryVisual = Category["image"] | Category["icon"] | string | null | undefined;

const SCROLL_STEP_FACTOR = 0.75;

function imageUrl(value: CategoryVisual): string | undefined {
  if (!value) return undefined;
  if (typeof value === "string") return value;
  return (value as any).cardUrl || value.url || undefined;
}

function categoryHref(category: Category): string {
  return `/products?category=${encodeURIComponent(category.slug || category._id)}&includeChildren=true`;
}

function CircleImage({
  url,
  name,
  priority = false,
}: {
  url: string;
  name: string;
  priority?: boolean;
}) {
  const { src, onError, onLoad, ref } = useResilientImage(url, "/placeholder.png");
  return (
    <img
      ref={ref}
      src={src}
      alt={name}
      loading={priority ? "eager" : "lazy"}
      fetchPriority={priority ? "high" : "auto"}
      decoding="async"
      onError={onError}
      onLoad={onLoad}
      style={{ opacity: 1 }}
    />
  );
}

/**
 * Homepage category strip — instant SSR paint without hydration opacity delay.
 */
export default function HomeCategoryShowcase({ categories }: HomeCategoryShowcaseProps) {
  const railRef = useRef<HTMLUListElement>(null);
  const [edge, setEdge] = useState<{ start: boolean; end: boolean }>({ start: true, end: false });
  const hasServerCategories = Array.isArray(categories) && categories.length > 0;

  const { data, error, isLoading, isValidating, mutate } = useSWR<Category[]>(
    "homepage-categories",
    () => categoryService.getHomepage(),
    {
      fallbackData: categories ?? undefined,
      // Avoid redundant client refetch on mount when SSR already supplied categories
      revalidateOnMount: !hasServerCategories,
      revalidateOnFocus: false,
      revalidateOnReconnect: true,
      dedupingInterval: 60000,
      errorRetryCount: 2,
      errorRetryInterval: 5000,
      keepPreviousData: true,
    }
  );

  const items = data ?? [];

  const showSkeleton = isLoading && items.length === 0;
  const showError = Boolean(error) && items.length === 0;
  const isScrollable = !showSkeleton && !showError && items.length > 1;

  const updateEdges = useCallback(() => {
    const rail = railRef.current;
    if (!rail) return;
    const maxScroll = rail.scrollWidth - rail.clientWidth;
    const offset = Math.abs(rail.scrollLeft);
    setEdge({ start: offset <= 1, end: offset >= maxScroll - 1 });
  }, []);

  useEffect(() => {
    updateEdges();
    window.addEventListener("resize", updateEdges);
    return () => window.removeEventListener("resize", updateEdges);
  }, [updateEdges, items.length]);

  const scrollRail = (direction: "next" | "prev") => {
    const rail = railRef.current;
    if (!rail) return;
    const amount = rail.clientWidth * SCROLL_STEP_FACTOR;
    rail.scrollBy({ left: direction === "next" ? -amount : amount, behavior: "smooth" });
  };

  if (!showSkeleton && !showError && items.length === 0) {
    return null;
  }

  return (
    <section className={styles.section} aria-busy={showSkeleton || undefined} data-home-categories="carousel">
      <h2 className={styles.srTitle}>دسته‌بندی‌های فروشگاه</h2>

      <div className={styles.stage}>
        {showSkeleton ? (
          <div className={styles.rail} role="status" aria-label="در حال بارگذاری دسته‌بندی‌ها">
            {Array.from({ length: 9 }, (_, index) => (
              <span key={index} className={styles.skeletonItem} aria-hidden="true">
                <span className={styles.skeletonBadge} />
                <span className={styles.skeletonLabel} />
              </span>
            ))}
          </div>
        ) : showError ? (
          <div className={styles.feedback} role="status">
            <p>بارگذاری دسته‌بندی‌ها انجام نشد.</p>
            <button
              type="button"
              className={styles.retry}
              disabled={isValidating}
              onClick={() => {
                void mutate();
              }}
            >
              {isValidating ? "در حال تلاش…" : "تلاش مجدد"}
            </button>
          </div>
        ) : (
          <ul ref={railRef} className={styles.rail} onScroll={updateEdges} aria-label="دسته‌بندی‌های فروشگاه">
            {items.map((category, index) => {
              const url = imageUrl(category.image) || imageUrl(category.icon);
              return (
                <li key={category._id || category.slug} className={styles.item}>
                  <Link
                    href={categoryHref(category)}
                    className={styles.category}
                    title={category.name}
                    data-category-id={category._id}
                  >
                    <span className={styles.badge}>
                      <span className={styles.disc}>
                        <span className={styles.hairline}>
                          {url ? (
                            <CircleImage url={url} name={category.name} priority={index < 8} />
                          ) : (
                            <Shapes className={styles.fallbackIcon} strokeWidth={1.5} aria-hidden="true" />
                          )}
                        </span>
                      </span>
                    </span>
                    <span className={styles.label}>{category.name}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}

        {isScrollable && (
          <>
            <button
              type="button"
              className={`${styles.nav} ${styles.navPrev}`}
              onClick={() => scrollRail("prev")}
              disabled={edge.start}
              aria-label="دسته‌بندی‌های قبلی"
            >
              <ChevronRight size={22} aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={scrollRail.bind(null, "next")}
              disabled={edge.end}
              aria-label="دسته‌بندی‌های بعدی"
            >
              <ChevronLeft size={22} aria-hidden="true" />
            </button>
          </>
        )}
      </div>
    </section>
  );
}
