/**
 * optimize-existing-s3-images.js
 * ============================================================================
 * بهینه‌سازی سرتاسری تصاویر موجود در پارس‌پک (Banners, Categories, Brands, Products):
 *
 * 1. بنرهای صفحه اصلی و میانی (Banner):
 *    - فشرده‌سازی درجا (In-Place) بنرهای دسکتاپ بالای ۲۲۰ کیلوبایت به 1920x600 WebP با کیفیت بالا (85)
 *    - ساخت نسخه پاسخگو/میانی `<uuid>-card.webp` (960x480 با کیفیت 84) و ثبت `cardUrl` در دیتابیس
 *    - فشرده‌سازی درجا بنرهای موبایل بالای ۱۱۰ کیلوبایت به 960x480 WebP با کیفیت 85
 *
 * 2. تصاویر و آیکون‌های دسته‌بندی (Category):
 *    - فشرده‌سازی درجا تصاویر دایره دسته‌بندی (`image`) بالای ۳۰ کیلوبایت به 320x320 Retina WebP با کیفیت 86 (~10-22KB)
 *    - فشرده‌سازی درجا آیکون‌های دسته‌بندی (`icon`) بالای ۱۸ کیلوبایت به 160x160 Retina WebP با کیفیت 86 (~5-12KB)
 *
 * 3. لوگوهای برند (Brand):
 *    - فشرده‌سازی درجا لوگوهای بالای ۳۰ کیلوبایت به 320x160 WebP با کیفیت 86
 *
 * 4. تصاویر محصولات (Product):
 *    - ساخت نسخه کارت `<uuid>-card.webp` (420x420 با کیفیت 78) و ثبت `cardUrl` در MongoDB
 *    - فشرده‌سازی درجا تصاویر اصلی محصول بالای ۱۸۰ کیلوبایت به 1200x1200 WebP با کیفیت 82
 *
 * Usage:
 *   node scripts/optimize-existing-s3-images.js            # live
 *   node scripts/optimize-existing-s3-images.js --dry-run  # preview only
 *   node scripts/optimize-existing-s3-images.js --verbose
 */

require('dotenv').config();
const mongoose = require('mongoose');
const axios = require('axios');
const Product = require('../models/Product');
const Banner = require('../models/Banner');
const Category = require('../models/Category');
const Brand = require('../models/Brand');
const { putObject, convertToWebp, cardKeyFor } = require('../lib/parspackS3');

const DRY_RUN = process.argv.includes('--dry-run');
const VERBOSE = process.argv.includes('--verbose');
const LIMIT = (() => {
  const i = process.argv.indexOf('--limit');
  const n = i >= 0 ? Number(process.argv[i + 1]) : NaN;
  return Number.isFinite(n) && n > 0 ? n : Infinity;
})();

const keyFromUrl = (url) => {
  try {
    const pathname = new URL(url).pathname; // /<bucket>/uploads/<file>
    const idx = pathname.indexOf('/uploads/');
    if (idx < 0) return null;
    return decodeURIComponent(pathname.slice(idx + 1)); // uploads/<file>
  } catch {
    return null;
  }
};

const fetchBuffer = async (url) => {
  const { data } = await axios.get(url, {
    responseType: 'arraybuffer',
    maxContentLength: 50 * 1024 * 1024,
    timeout: 25000,
  });
  return Buffer.from(data);
};

const optimizeBanners = async () => {
  const banners = await Banner.find({}).lean();
  console.log(`\n🖼️  [Banners] Total banners: ${banners.length}`);
  let updated = 0;

  for (const banner of banners) {
    let changed = false;
    const nextImage = banner.image && typeof banner.image === 'object' ? { ...banner.image } : null;
    const nextMobile = banner.mobileImage && typeof banner.mobileImage === 'object' ? { ...banner.mobileImage } : null;

    if (nextImage && typeof nextImage.url === 'string') {
      const key = keyFromUrl(nextImage.url);
      if (key && !/\.gif$/i.test(key)) {
        try {
          const origBuf = await fetchBuffer(nextImage.url);
          // 1) In-place optimize desktop banner if > 220KB
          if (origBuf.length > 220 * 1024) {
            const optMain = await convertToWebp(origBuf, { maxWidth: 1920, maxHeight: 600, quality: 85 });
            if (optMain && optMain.length < origBuf.length) {
              if (!DRY_RUN) await putObject(optMain, key, 'image/webp');
              console.log(`  ✨ Banner desktop optimized [${banner.title}]: ${Math.round(origBuf.length / 1024)}KB → ${Math.round(optMain.length / 1024)}KB`);
              changed = true;
            }
          }
          // 2) Create 960x480 cardUrl for middle-banners / mobile fallback if missing
          const cardKey = cardKeyFor(key);
          if (cardKey && (!nextImage.cardUrl || nextImage.cardUrl === nextImage.url)) {
            const cardBuf = await convertToWebp(origBuf, { maxWidth: 960, maxHeight: 480, quality: 84 });
            if (cardBuf) {
              if (!DRY_RUN) {
                const res = await putObject(cardBuf, cardKey, 'image/webp');
                nextImage.cardUrl = res.url;
              }
              console.log(`  ✅ Banner cardUrl created [${banner.title}]: ${Math.round(cardBuf.length / 1024)}KB`);
              changed = true;
            }
          }
        } catch (err) {
          console.warn(`  ⚠️ Banner desktop error (${banner.title}): ${err.message}`);
        }
      }
    }

    if (nextMobile && typeof nextMobile.url === 'string') {
      const mKey = keyFromUrl(nextMobile.url);
      if (mKey && !/\.gif$/i.test(mKey)) {
        try {
          const origMobile = await fetchBuffer(nextMobile.url);
          if (origMobile.length > 100 * 1024) {
            const optMobile = await convertToWebp(origMobile, { maxWidth: 960, maxHeight: 480, quality: 85 });
            if (optMobile && optMobile.length < origMobile.length) {
              if (!DRY_RUN) await putObject(optMobile, mKey, 'image/webp');
              console.log(`  ✨ Banner mobile optimized [${banner.title}]: ${Math.round(origMobile.length / 1024)}KB → ${Math.round(optMobile.length / 1024)}KB`);
              changed = true;
            }
          }
        } catch (err) {
          console.warn(`  ⚠️ Banner mobile error (${banner.title}): ${err.message}`);
        }
      }
    }

    if (changed) {
      if (!DRY_RUN) {
        await Banner.updateOne(
          { _id: banner._id },
          {
            $set: {
              ...(nextImage ? { image: nextImage } : {}),
              ...(nextMobile ? { mobileImage: nextMobile } : {}),
            },
          }
        );
      }
      updated++;
    }
  }
  console.log(`✅ [Banners] Optimized/updated: ${updated}`);
};

const optimizeCategories = async () => {
  const categories = await Category.find({}).lean();
  console.log(`\n📂 [Categories] Total categories: ${categories.length}`);
  let optimizedCount = 0;

  for (const cat of categories) {
    for (const [field, maxDim, thresholdKb] of [
      ['image', 320, 30],
      ['icon', 160, 18],
    ]) {
      const entry = cat[field];
      const url = typeof entry === 'string' ? entry : entry?.url;
      if (!url) continue;
      const key = keyFromUrl(url);
      if (!key || /\.gif$/i.test(key)) continue;

      try {
        const origBuf = await fetchBuffer(url);
        if (origBuf.length <= thresholdKb * 1024) continue;

        const optBuf = await convertToWebp(origBuf, {
          maxWidth: maxDim,
          maxHeight: maxDim,
          quality: 86,
        });
        if (optBuf && optBuf.length < origBuf.length) {
          if (!DRY_RUN) await putObject(optBuf, key, 'image/webp');
          console.log(
            `  ✨ Category ${field} [${cat.name}]: ${Math.round(origBuf.length / 1024)}KB → ${Math.round(optBuf.length / 1024)}KB`
          );
          optimizedCount++;
        }
      } catch (err) {
        console.warn(`  ⚠️ Category ${field} error (${cat.name}): ${err.message}`);
      }
    }
  }
  console.log(`✅ [Categories] Images/icons optimized in-place: ${optimizedCount}`);
};

const optimizeBrands = async () => {
  const brands = await Brand.find({}).lean();
  console.log(`\n🏷️  [Brands] Total brands: ${brands.length}`);
  let optimizedCount = 0;

  for (const brand of brands) {
    const url = typeof brand.logo === 'string' ? brand.logo : brand.logo?.url;
    if (!url) continue;
    const key = keyFromUrl(url);
    if (!key || /\.gif$/i.test(key)) continue;

    try {
      const origBuf = await fetchBuffer(url);
      if (origBuf.length <= 30 * 1024) continue;

      const optBuf = await convertToWebp(origBuf, {
        maxWidth: 320,
        maxHeight: 160,
        quality: 86,
      });
      if (optBuf && optBuf.length < origBuf.length) {
        if (!DRY_RUN) await putObject(optBuf, key, 'image/webp');
        console.log(
          `  ✨ Brand logo [${brand.name}]: ${Math.round(origBuf.length / 1024)}KB → ${Math.round(optBuf.length / 1024)}KB`
        );
        optimizedCount++;
      }
    } catch (err) {
      console.warn(`  ⚠️ Brand logo error (${brand.name}): ${err.message}`);
    }
  }
  console.log(`✅ [Brands] Logos optimized in-place: ${optimizedCount}`);
};

const main = async () => {
  console.log('╔══════════════════════════════════════════════════════╗');
  console.log('║  🖼️  S3 Full-Catalog Image Optimization & Backfill   ║');
  console.log('╚══════════════════════════════════════════════════════╝');
  console.log(`Mode: ${DRY_RUN ? '🔍 DRY RUN' : '⚡ LIVE RUN'}`);

  const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/ekgkala';
  await mongoose.connect(mongoUri);
  console.log(`✅ Connected: ${mongoose.connection.host}`);

  // 1. Optimize Banners, Categories, and Brands first (Homepage critical LCP path)
  await optimizeBanners();
  await optimizeCategories();
  await optimizeBrands();

  // 2. Optimize Products and backfill cardUrl
  const products = await Product.find({}).lean();
  console.log(`\n📦 [Products] Total products: ${products.length}`);

  let scanned = 0, created = 0, skipped = 0, failed = 0;

  for (const product of products) {
    const images = Array.isArray(product.images) ? product.images : [];
    if (images.length === 0) continue;

    let changed = false;

    for (let i = 0; i < images.length; i++) {
      const img = images[i];
      if (!img || typeof img !== 'object' || typeof img.url !== 'string') continue;
      if (typeof img.cardUrl === 'string' && img.cardUrl.trim() && img.cardUrl !== img.url) {
        skipped++;
        continue;
      }

      scanned++;
      if (scanned > LIMIT) { console.log('⏹  --limit reached'); break; }

      const key = keyFromUrl(img.url);
      const cardKey = key ? cardKeyFor(key) : null;
      if (!key || !cardKey) { skipped++; continue; }

      try {
        if (VERBOSE || DRY_RUN) console.log(`  [${product._id}] ${String(product.name).slice(0, 40)} → ${cardKey}`);
        if (DRY_RUN) { created++; continue; }

        const origBuf = await fetchBuffer(img.url);
        const cardBuf = await convertToWebp(origBuf, { maxWidth: 420, maxHeight: 420, quality: 78 });
        if (!cardBuf) { failed++; console.warn(`  ⚠️  conversion failed for ${key}`); continue; }

        // If main product image is > 180KB, optimize it in-place too
        if (origBuf.length > 180 * 1024) {
          const optMain = await convertToWebp(origBuf, { maxWidth: 1200, maxHeight: 1200, quality: 82 });
          if (optMain && optMain.length < origBuf.length) {
            await putObject(optMain, key, 'image/webp');
          }
        }

        const res = await putObject(cardBuf, cardKey, 'image/webp');
        images[i] = { ...img, cardUrl: res.url };
        changed = true;
        created++;
      } catch (err) {
        failed++;
        console.error(`  ❌ ${key}: ${err.message}`);
      }
    }

    if (changed) {
      await Product.updateOne({ _id: product._id }, { $set: { images } });
    }
    if (scanned > LIMIT) break;
  }

  console.log('\n╔══════════════════════════════════════════════════════╗');
  console.log('║  📊 Product Summary                                  ║');
  console.log(`║  ✅ Card variants created: ${created}`);
  console.log(`║  ⏭️  Skipped (already had cardUrl): ${skipped}`);
  console.log(`║  ❌ Failed: ${failed}`);
  console.log('╚══════════════════════════════════════════════════════╝');
  if (DRY_RUN) console.log('🔍 DRY RUN — no changes were made.');

  await mongoose.disconnect();
};

main().catch(async (err) => {
  console.error('❌ Migration failed:', err);
  try { await mongoose.disconnect(); } catch {}
  process.exit(1);
});
